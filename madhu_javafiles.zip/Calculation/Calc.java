package Calculation;

public class Calc

{
    public void addition()

        {
            int a = 10;
            int b = 12;
            int c = a + b;
            System.out.println("The addition value is:" +c);
        }

    public float subtraction()

    {
        float s1=120,s2=79;
        float sub=s1-s2;
        return sub;

    }

    public void multiplication() {
        int _m1 = 23;
        int m2 = 10;

        int mul = _m1 * m2;

        System.out.println("Multiplication of two numbers is:" + mul);


    }

    public double division() {
        double d1, d2;
        d1 = 45L;
        d2 = 8L;
         double div = d1 / d2;
        return div;


    }

    }
class Mycalc
    {
        public static void main(String[] args)

        {
            Calc c1=new Calc();
            c1.addition();
            float s2=c1.subtraction();
            System.out.println("The Subtraction value is:" +s2);
            c1.multiplication();
            double l1=c1.division();
            System.out.println("The division vaue is:" +l1);

        }


    }


