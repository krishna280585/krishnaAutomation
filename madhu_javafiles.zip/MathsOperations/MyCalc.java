package MathsOperations;


public class MyCalc {

    public static void main(String args[]) {
        Calc calculation = new Calc();
        calculation.addition();
        float callValue= calculation.subtraction();
        System.out.println("Substract of two numbers:" + callValue);
        Calc1 cal=new Calc1();
        float divValue=cal.division();
        System.out.println("division is" +divValue);
        cal.multiplication();
        System.out.println("successfuly done");


    }


}
