package MathsOperations;

public class Calc1 {

    public void multiplication() {
        int _m1 = 23;
        int m2 = 10;

        int mul = _m1 * m2;

        System.out.println("Multiplication of two numbers is:" + mul);


    }

    public float division() {
        float d1, d2;
        d1 = 45L;
        d2 = 8L;
        float div = d1 / d2;
        return div;


    }
}