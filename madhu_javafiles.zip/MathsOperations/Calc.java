package MathsOperations;

public class Calc
{
    public void addition()
    {
        int a1,a2;
        a1=20;
        a2=35;
        int add=a1+a2;
        System.out.println("Addition of" +a1+ "and" +a2+ "is:"+ add);

    }
   public float subtraction()
   {
       float s1=120,s2=79;
       float sub=s1-s2;
       return sub;

   }


}
