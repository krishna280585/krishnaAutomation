package Variables;

public class DataTypes1
{

    int i=50;

   public static void main(String[] args)


    {
        int n=21;
        //System.out.println(n);
        DataTypes1 d2=new DataTypes1();
        d2.add();
        System.out.println(n);
        d2.sub();
    }

    public void add()
    {
        int a=i,b=10,c;
        c=a+b;
        System.out.println("the addition value is:"+c);

    }

    public void sub()
    {
        float f1=i;
        int f2=30;
        float f3=f1-f2;

        System.out.println("the sub value is:"+f3);

    }
}
