package Variables;

public class Datatypes3
{
    public static void main(String[] args)
    {
         byte a=12;
        byte   b=3;
        long c=a+b;
        int d=a-b;
        float e=a*b;
        double f=a/b;
       //short g=a+b;

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(e);
        System.out.println(f);


    }
}
