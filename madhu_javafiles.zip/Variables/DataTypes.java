package Variables;

public class DataTypes
{
public static void main(String args[])
{

    DataTypes dt=new DataTypes();
    dt.data();
    long longValue=dt.mul();
    System.out.println("the multiplication value is:"+ longValue);
}

public void data()
{
    int a=127;
    double dl= 5434d;
    float fl=23675f;
    short e=32761;
    double c_1=2128936d;
    float _e=e;
    char ch= 'a';
    String name= " madhu ";
    String house_no="80 skeffington road";
    System.out.println(ch);
    System.out.println(name);
    System.out.println(house_no);
    System.out.println("The integer value is:" +a);
    System.out.println("the short value is:" +e);
    System.out.println("The double value is:"+ dl);
    System.out.println("The float value is:" +fl);
    System.out.println("The double vaue is:" + c_1);
    System.out.println("The changed float value is:" + _e);

}

public long mul()
{
    long b1=2500l;
    long b2=1011l;
    //byte c;
    //c=a+b;
    long b3=b1*b2;
   return b3;


}


}

